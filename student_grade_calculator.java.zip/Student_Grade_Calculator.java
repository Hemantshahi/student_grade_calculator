/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

******************************/
import java.util.Scanner;
public class Student_Grade_Calculator
{
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
	    System.out.println("student grade calculator");
	    System.out.println("Enter number of subjects");
	    int nS=sc.nextInt();
	    int total=0;
	    for(int i=0;i<nS;i++){
	        System.out.println("Enter marks obtained in "+i+": ");
	        int marks=sc.nextInt();
	        total+=marks;
	    }
	    double averP=(double)total/nS;
	    char Grade;
	    if(averP>=90){
	        Grade='o';
	    }
	    else if(averP>=80){
	        Grade='A';
	    }
	    else if(averP>=70){
	        Grade='B';
	    }
	    else if(averP>=60){
	        Grade='C';
	    }
	    else if(averP>=40){
	        Grade='E';
	    }
	    else{
	        Grade='F';
	    }
	    System.out.println("Total marks scored is "+total);
	    System.out.println("Average percentage gained is "+averP +"%");
	    System.out.println("Grade :"+Grade);
	}
}
